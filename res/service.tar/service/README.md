#### jkd 需要手动下载

`wget https://d6.injdk.cn/oraclejdk/11/jdk-11.0.2_linux-x64_bin.tar.gz`